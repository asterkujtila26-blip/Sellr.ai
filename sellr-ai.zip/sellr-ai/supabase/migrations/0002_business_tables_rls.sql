-- ============================================================================
-- SELLR.AI — Supabase migration 0002
-- Ownership RLS for SELLR.AI business tables.
--
-- APPLY WHEN: business data is migrated from the app's Prisma/SQLite store to
-- the Supabase Postgres database (tables below are created there). Until then
-- the app enforces the identical rules server-side on every API route
-- (requireUser + ownership checks in src/lib/auth.ts).
-- ============================================================================

-- 1. Business tables ----------------------------------------------------------

create table if not exists public.businesses (
  id                    uuid primary key default gen_random_uuid(),
  owner_id              uuid not null references public.profiles (id) on delete cascade,
  name                  text not null,
  business_type         text not null,
  platform              text,
  website               text,
  description           text,
  products              text,
  target_audience       text,
  current_monthly_revenue numeric,
  monthly_revenue_goal  numeric,
  main_challenge        text,
  onboarded             boolean not null default false,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create table if not exists public.business_metrics (
  id            uuid primary key default gen_random_uuid(),
  business_id   uuid not null references public.businesses (id) on delete cascade,
  metric_type   text not null,
  metric_value  numeric not null,
  period        text not null,
  source        text not null default 'MANUAL',
  recorded_at   timestamptz not null default now(),
  unique (business_id, metric_type, period)
);

create table if not exists public.conversations (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles (id) on delete cascade,
  business_id  uuid not null references public.businesses (id) on delete cascade,
  agent_type   text not null default 'CEO',
  title        text not null default 'New conversation',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  role            text not null,
  content         text not null,
  agent_type      text,
  meta            jsonb,
  created_at      timestamptz not null default now()
);

create table if not exists public.recommendations (
  id              uuid primary key default gen_random_uuid(),
  business_id     uuid not null references public.businesses (id) on delete cascade,
  agent_type      text not null,
  title           text not null,
  description     text not null,
  priority        text not null default 'MEDIUM',
  expected_impact text,
  status          text not null default 'SUGGESTED',
  created_at      timestamptz not null default now()
);

create table if not exists public.tasks (
  id                uuid primary key default gen_random_uuid(),
  business_id       uuid not null references public.businesses (id) on delete cascade,
  recommendation_id uuid references public.recommendations (id) on delete set null,
  title             text not null,
  description       text,
  assigned_agent    text not null default 'OPERATIONS',
  priority          text not null default 'MEDIUM',
  status            text not null default 'PLANNED',
  due_date          timestamptz,
  completed_at      timestamptz,
  created_at        timestamptz not null default now()
);

create table if not exists public.experiments (
  id             uuid primary key default gen_random_uuid(),
  business_id    uuid not null references public.businesses (id) on delete cascade,
  title          text not null,
  hypothesis     text,
  metric         text,
  baseline_value numeric,
  target_value   numeric,
  result_value   numeric,
  status         text not null default 'PLANNED',
  created_at     timestamptz not null default now(),
  completed_at   timestamptz
);

create table if not exists public.activities (
  id          uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete cascade,
  type        text not null,
  description text not null,
  agent_type  text,
  created_at  timestamptz not null default now()
);

create index if not exists businesses_owner_idx on public.businesses (owner_id);
create index if not exists metrics_business_idx on public.business_metrics (business_id, metric_type, period);
create index if not exists conversations_user_idx on public.conversations (user_id);
create index if not exists messages_conversation_idx on public.messages (conversation_id);
create index if not exists recommendations_business_idx on public.recommendations (business_id, status);
create index if not exists tasks_business_idx on public.tasks (business_id, status);
create index if not exists experiments_business_idx on public.experiments (business_id);
create index if not exists activities_business_idx on public.activities (business_id, created_at);

-- 2. Row Level Security — EVERY table gets an ownership policy ----------------

alter table public.businesses       enable row level security;
alter table public.business_metrics enable row level security;
alter table public.conversations    enable row level security;
alter table public.messages         enable row level security;
alter table public.recommendations  enable row level security;
alter table public.tasks            enable row level security;
alter table public.experiments      enable row level security;
alter table public.activities       enable row level security;

-- Businesses: full CRUD for the owner only.
drop policy if exists "businesses_owner_all" on public.businesses;
create policy "businesses_owner_all"
  on public.businesses for all
  using (auth.uid() = owner_id)
  with check (auth.uid() = owner_id);

-- Child tables: ownership via the parent business.
drop policy if exists "metrics_owner_all" on public.business_metrics;
create policy "metrics_owner_all"
  on public.business_metrics for all
  using (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  );

drop policy if exists "conversations_owner_all" on public.conversations;
create policy "conversations_owner_all"
  on public.conversations for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Messages are scoped through their conversation's user.
drop policy if exists "messages_owner_all" on public.messages;
create policy "messages_owner_all"
  on public.messages for all
  using (
    exists (
      select 1 from public.conversations c
      where c.id = conversation_id and c.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.conversations c
      where c.id = conversation_id and c.user_id = auth.uid()
    )
  );

drop policy if exists "recommendations_owner_all" on public.recommendations;
create policy "recommendations_owner_all"
  on public.recommendations for all
  using (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  );

drop policy if exists "tasks_owner_all" on public.tasks;
create policy "tasks_owner_all"
  on public.tasks for all
  using (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  );

drop policy if exists "experiments_owner_all" on public.experiments;
create policy "experiments_owner_all"
  on public.experiments for all
  using (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  );

drop policy if exists "activities_owner_all" on public.activities;
create policy "activities_owner_all"
  on public.activities for all
  using (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.businesses b
      where b.id = business_id and b.owner_id = auth.uid()
    )
  );

-- 3. Verification helper (optional, run as SQL editor query) -------------------
-- Every business row must be readable by exactly one owner. This query returns
-- rows that would be orphaned from any owner — should always return 0 rows:
--
--   select count(*) from public.businesses
--   where owner_id not in (select id from public.profiles);
