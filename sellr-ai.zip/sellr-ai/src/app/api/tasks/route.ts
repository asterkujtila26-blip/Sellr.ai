import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { taskCreateSchema } from '@/lib/validation'
import { logActivity } from '@/lib/activity'

export async function GET() {
  try {
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const tasks = await db.task.findMany({
      where: { businessId: business.id },
      orderBy: { createdAt: 'desc' },
      take: 200,
    })
    return NextResponse.json({ tasks })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const body = await req.json()
    const input = taskCreateSchema.parse(body)

    // If linked to a recommendation, verify it belongs to this business.
    if (input.recommendationId) {
      const rec = await db.recommendation.findUnique({ where: { id: input.recommendationId } })
      if (!rec || rec.businessId !== business.id) {
        throw new ApiError(404, 'Recommendation not found.')
      }
    }

    const task = await db.task.create({
      data: {
        businessId: business.id,
        recommendationId: input.recommendationId ?? null,
        title: input.title,
        description: input.description ?? null,
        assignedAgent: input.assignedAgent,
        priority: input.priority,
        dueDate: input.dueDate ? new Date(input.dueDate) : null,
        status: 'PLANNED',
      },
    })
    await logActivity(business.id, 'TASK_CREATED', `Task created: "${task.title}"`)
    return NextResponse.json({ task })
  } catch (e) {
    return errorResponse(e)
  }
}
