import { NextRequest, NextResponse } from 'next/server'
import { assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { logActivity } from '@/lib/activity'
import { db } from '@/lib/db'
import { openSecret } from '@/lib/whop/crypto'
import { deleteWebhook } from '@/lib/whop/client'
import type { WhopEnvironment } from '@/lib/whop/config'

/**
 * Disconnect the Whop business: best-effort webhook deregistration at Whop,
 * then delete the stored credential and all related records. Deletion of the
 * row destroys the encrypted key material — the credential is unrecoverable.
 */
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const business = await requireBusiness(user.id)

    const connection = await db.whopConnection.findUnique({ where: { businessId: business.id } })
    if (!connection) {
      return NextResponse.json({ ok: true, already: true })
    }

    // Best-effort webhook deregistration with the stored credential.
    if (connection.webhookId && connection.webhookEncryptedSecret) {
      try {
        const apiKey = openSecret({
          ciphertext: connection.encryptedKey,
          iv: connection.keyIv,
          tag: connection.keyTag,
        })
        await deleteWebhook(connection.environment as WhopEnvironment, apiKey, connection.webhookId)
      } catch {
        // The key may be revoked or the webhook already deleted — proceed.
      }
    }

    // Remove the idempotency ledger rows, then the credential itself.
    await db.whopWebhookEvent.deleteMany({ where: { connectionId: connection.id } })
    await db.whopConnection.delete({ where: { id: connection.id } })

    await logActivity(
      business.id,
      'WHOP_DISCONNECTED',
      `Whop account disconnected (${connection.whopAccountId}). Stored credentials were deleted.`,
      null
    )

    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
