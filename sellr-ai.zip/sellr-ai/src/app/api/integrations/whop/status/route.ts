import { NextResponse } from 'next/server'
import { errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { buildWhopStatus } from '@/lib/whop/status'
import { isWhopEncryptionConfigured, isWhopWebhookConfigured } from '@/lib/whop/config'

/**
 * Public integration status for the signed-in user's SELLR business.
 * Returns a null connection (with configuration flags) when there is nothing
 * connected yet or the user has no business — never an error.
 */
export async function GET() {
  try {
    const user = await requireUser().catch(() => null)
    if (!user) {
      return NextResponse.json({
        configured: isWhopEncryptionConfigured(),
        webhookConfigured: isWhopWebhookConfigured(),
        connection: null,
      })
    }
    const business = await requireBusiness(user.id).catch(() => null)
    if (!business) {
      return NextResponse.json({
        configured: isWhopEncryptionConfigured(),
        webhookConfigured: isWhopWebhookConfigured(),
        connection: null,
      })
    }
    return NextResponse.json(await buildWhopStatus(business.id))
  } catch (e) {
    return errorResponse(e)
  }
}
