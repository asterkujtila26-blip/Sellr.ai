import { NextRequest, NextResponse } from 'next/server'
import type { Recommendation as DbRecommendation } from '@prisma/client'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { chatSchema } from '@/lib/validation'
import { rateLimit } from '@/lib/rate-limit'
import { logActivity } from '@/lib/activity'
import { buildSharedContext } from '@/lib/agents/context'
import { runAgentTurn } from '@/lib/agents/orchestrator'

// Several sequential LLM calls per turn — give the serverless function room (Vercel).
export const maxDuration = 60

const AGENT_NAMES: Record<string, string> = {
  CEO: 'SELLR CEO',
  ANALYST: 'Analyst',
  GROWTH: 'Growth',
  RETENTION: 'Retention',
  OPERATIONS: 'Operations',
}

/**
 * The main agent endpoint (SELLR.md §4.4, §9).
 * Flow: auth → rate limit → ownership → shared memory → orchestration →
 * persist messages + recommendations → respond.
 */
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()

    const rl = rateLimit(`chat:${user.id}`, 20, 5 * 60_000)
    if (!rl.ok) {
      throw new ApiError(
        429,
        `You're sending messages quickly. The team needs a moment — try again in ${rl.retryAfterSec}s.`
      )
    }

    const body = await req.json()
    const input = chatSchema.parse(body)

    const business = await requireBusiness(user.id)
    if (!business.onboarded) {
      throw new ApiError(400, 'Complete onboarding before talking to your AI team.')
    }

    // --- Resolve or create the conversation (ownership verified) ---
    let conversation
    if (input.conversationId) {
      conversation = await db.conversation.findUnique({ where: { id: input.conversationId } })
      if (!conversation || conversation.userId !== user.id) {
        throw new ApiError(404, 'Conversation not found.')
      }
    } else {
      const title =
        input.message.length > 60 ? `${input.message.slice(0, 60)}…` : input.message
      conversation = await db.conversation.create({
        data: {
          userId: user.id,
          businessId: business.id,
          agentType: input.agentType,
          title,
        },
      })
    }

    // --- Persist the user's message ---
    const userMessage = await db.message.create({
      data: {
        conversationId: conversation.id,
        role: 'user',
        content: input.message,
      },
    })

    // --- Conversation history (excluding the just-saved message) ---
    const historyRows = await db.message.findMany({
      where: { conversationId: conversation.id },
      orderBy: { createdAt: 'asc' },
      take: 40,
    })
    const history = historyRows
      .slice(0, -1)
      .map((m) => ({ role: m.role === 'user' ? ('user' as const) : ('assistant' as const), content: m.content }))

    // --- Shared business memory ---
    const { context } = await buildSharedContext(business.id)

    // --- Orchestrate the agent turn ---
    const turn = await runAgentTurn({
      agentType: input.agentType,
      message: input.message,
      history,
      context,
    })

    // --- Persist agent recommendations (max 3 per turn) ---
    const sourceAgent = turn.delegatedTo ?? input.agentType
    const savedRecommendations: DbRecommendation[] = []
    for (const rec of turn.recommendations.slice(0, 3)) {
      const saved = await db.recommendation.create({
        data: {
          businessId: business.id,
          agentType: sourceAgent,
          title: rec.title,
          description: rec.description,
          priority: rec.priority,
          expectedImpact: rec.expectedImpact,
          status: 'SUGGESTED',
        },
      })
      savedRecommendations.push(saved)
    }

    // --- Persist the assistant message ---
    const meta = JSON.stringify({
      pipeline: turn.pipeline,
      agentsInvolved: turn.agentsInvolved,
      confidence: turn.confidence,
      delegatedTo: turn.delegatedTo,
      intent: turn.intent,
    })
    const assistantMessage = await db.message.create({
      data: {
        conversationId: conversation.id,
        role: 'assistant',
        content: turn.reply,
        agentType: input.agentType,
        meta,
      },
    })

    await db.conversation.update({
      where: { id: conversation.id },
      data: { agentType: input.agentType },
    })

    // --- Activity log ---
    const agentName = AGENT_NAMES[input.agentType] ?? input.agentType
    const intentLabel = turn.intent ?? 'general request'
    await logActivity(
      business.id,
      'AGENT_SESSION',
      `${agentName} handled: "${intentLabel}"`,
      input.agentType
    )
    if (savedRecommendations.length > 0) {
      await logActivity(
        business.id,
        'RECOMMENDATION_CREATED',
        `${savedRecommendations.length} new recommendation${savedRecommendations.length > 1 ? 's' : ''} from ${AGENT_NAMES[sourceAgent] ?? sourceAgent}`,
        sourceAgent
      )
    }

    return NextResponse.json({
      conversation,
      userMessage,
      assistantMessage,
      savedRecommendations,
    })
  } catch (e) {
    return errorResponse(e)
  }
}
