import { NextRequest, NextResponse } from 'next/server'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { resendVerificationSchema } from '@/lib/validation'
import { rateLimit } from '@/lib/rate-limit'
import { isSupabaseConfigured } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'
import { mapSupabaseAuthError } from '@/lib/supabase/errors'

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local'
    const rl = rateLimit(`resend:${ip}`, 5, 10 * 60_000)
    if (!rl.ok) {
      throw new ApiError(429, `Too many emails sent. Try again in ${rl.retryAfterSec}s.`)
    }

    const body = await req.json()
    const { email } = resendVerificationSchema.parse(body)

    // ---------------- Supabase provider ----------------
    if (isSupabaseConfigured) {
      const supabase = await createSupabaseServerClient()
      const { error } = await supabase.auth.resend({ type: 'signup', email })
      if (error) throw mapSupabaseAuthError(error)
      return NextResponse.json({ ok: true })
    }

    // ---------------- Local provider ----------------
    // The local provider verifies accounts at sign-up time (no pending
    // verification state), so there is nothing to resend.
    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
