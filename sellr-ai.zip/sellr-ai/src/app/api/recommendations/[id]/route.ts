import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireUser } from '@/lib/auth'
import { recommendationStatusSchema } from '@/lib/validation'
import { logActivity } from '@/lib/activity'

async function getOwnedRecommendation(userId: string, id: string) {
  const recommendation = await db.recommendation.findUnique({ where: { id } })
  if (!recommendation) throw new ApiError(404, 'Recommendation not found.')
  const business = await db.business.findUnique({ where: { id: recommendation.businessId } })
  if (!business || business.ownerId !== userId) throw new ApiError(404, 'Recommendation not found.')
  return recommendation
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params
    const recommendation = await getOwnedRecommendation(user.id, id)

    const body = await req.json()
    const { status } = recommendationStatusSchema.parse(body)

    const updated = await db.recommendation.update({
      where: { id: recommendation.id },
      data: { status },
    })
    await logActivity(
      updated.businessId,
      'RECOMMENDATION_STATUS',
      `Recommendation "${updated.title}" → ${status.toLowerCase().replace('_', ' ')}`
    )
    return NextResponse.json({ recommendation: updated })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params
    const recommendation = await getOwnedRecommendation(user.id, id)

    await db.recommendation.delete({ where: { id: recommendation.id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
