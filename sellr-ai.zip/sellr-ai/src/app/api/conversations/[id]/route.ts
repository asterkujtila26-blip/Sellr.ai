import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireUser } from '@/lib/auth'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireUser()
    const { id } = await params

    const conversation = await db.conversation.findUnique({ where: { id } })
    if (!conversation || conversation.userId !== user.id) {
      throw new ApiError(404, 'Conversation not found.')
    }
    const messages = await db.message.findMany({
      where: { conversationId: conversation.id },
      orderBy: { createdAt: 'asc' },
      take: 200,
    })
    return NextResponse.json({ conversation, messages })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params

    const conversation = await db.conversation.findUnique({ where: { id } })
    if (!conversation || conversation.userId !== user.id) {
      throw new ApiError(404, 'Conversation not found.')
    }
    await db.conversation.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
