import { NextResponse, type NextRequest } from 'next/server'
import { createServerClient } from '@supabase/ssr'
import { SUPABASE_ANON_KEY, SUPABASE_URL, isSupabaseConfigured } from '@/lib/supabase/config'

/**
 * Proxy (formerly middleware): keeps the Supabase session fresh on every page
 * navigation.
 *
 * Expired access tokens are refreshed transparently and the rotated cookies
 * are written onto the response — this is what makes "refresh never logs the
 * user out" true at the edge. When Supabase is not configured the proxy is a
 * no-op passthrough.
 *
 * NOTE: real authorization always happens inside the API route handlers via
 * requireUser() (server-verified). The SPA view gating is UX only.
 */
export default async function proxy(request: NextRequest) {
  if (!isSupabaseConfigured) return NextResponse.next()

  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(SUPABASE_URL!, SUPABASE_ANON_KEY!, {
    cookies: {
      getAll() {
        return request.cookies.getAll()
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
        supabaseResponse = NextResponse.next({ request })
        cookiesToSet.forEach(({ name, value, options }) =>
          supabaseResponse.cookies.set(name, value, options)
        )
      },
    },
  })

  // IMPORTANT: do not run code between createServerClient and getUser() —
  // getUser() both validates and refreshes the session.
  await supabase.auth.getUser()

  return supabaseResponse
}

export const config = {
  matcher: [
    // Refresh on page loads, skip API routes (they refresh in-handler),
    // static assets, and the callback route (which performs its own exchange).
    '/((?!api|_next/static|_next/image|auth/callback|favicon.ico|robots.txt|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
