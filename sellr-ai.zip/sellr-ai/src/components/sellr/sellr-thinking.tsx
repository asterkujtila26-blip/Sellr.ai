import { cn } from '@/lib/utils'

/**
 * SELLR NEURAL CORE — the branded "thinking" animation.
 *
 * Visual concept: a central glowing orange core carrying the SELLR "S",
 * two counter-rotating orbital rings, four orbiting nodes colored after the
 * four specialist agents (Analyst / Growth / Retention / Operations), an
 * expanding energy pulse, and a status line.
 *
 * Engineering:
 *  - Pure CSS keyframes (transform/opacity only) — no JS timers, no re-renders.
 *  - The parent owns the lifecycle: the component renders only while the chat
 *    request is actually in flight, and unmounts on success/error.
 *  - `prefers-reduced-motion` freezes every loop (globals.css kill list); the
 *    status text remains fully readable.
 *  - Decorative layers are aria-hidden; the status line is a polite live region.
 */

/** Orbiting node colors — mirrors AGENT_META accent colors (types.ts). */
const ORBIT_NODES = [
  { color: '#34D399', glow: 'rgba(52, 211, 153, 0.55)' }, // ANALYST
  { color: '#FBBF24', glow: 'rgba(251, 191, 36, 0.55)' }, // GROWTH
  { color: '#F472B6', glow: 'rgba(244, 114, 182, 0.55)' }, // RETENTION
  { color: '#22D3EE', glow: 'rgba(34, 211, 238, 0.55)' }, // OPERATIONS
]

export function SellrThinking({ status }: { status: string }) {
  return (
    <div
      role="status"
      aria-live="polite"
      className="flex flex-col items-center gap-4 py-6"
    >
      <div
        className="relative h-32 w-32 sm:h-36 sm:w-36"
        aria-hidden
      >
        {/* Energy pulse — expanding ring behind the core */}
        <span className="neural-core-pulse absolute inset-6 rounded-full border border-primary/50" />

        {/* Soft glow disc — opacity only, cheap on large surfaces */}
        <span className="neural-core-glow absolute inset-4 rounded-full bg-primary/25" />

        {/* Orbital ring 1 — rotating highlight arc */}
        <span className="neural-core-spin absolute inset-1 rounded-full border border-border/70 border-t-primary/70" />

        {/* Orbital ring 2 — counter-rotating dashed orbit */}
        <span className="neural-core-spin-rev absolute inset-4 rounded-full border border-dashed border-border/50 border-b-primary/30" />

        {/* Four specialist nodes orbiting the core */}
        <span className="neural-core-spin absolute inset-0">
          {ORBIT_NODES.map((node, i) => {
            const positions = [
              'left-1/2 top-0 -translate-x-1/2 -translate-y-1/2',
              'right-0 top-1/2 translate-x-1/2 -translate-y-1/2',
              'left-1/2 bottom-0 -translate-x-1/2 translate-y-1/2',
              'left-0 top-1/2 -translate-x-1/2 -translate-y-1/2',
            ]
            return (
              <span
                key={i}
                className={cn('absolute h-2 w-2 rounded-full', positions[i])}
                style={{ backgroundColor: node.color, boxShadow: `0 0 8px 1px ${node.glow}` }}
              />
            )
          })}
        </span>

        {/* Central core — breathing "S" */}
        <span className="absolute inset-[2.1rem] flex items-center justify-center rounded-2xl border border-primary/60 bg-primary shadow-[0_4px_28px_rgba(255,78,0,0.45)]">
          <span className="neural-core-breathe flex h-full w-full items-center justify-center rounded-2xl bg-primary">
            <span className="text-2xl font-black leading-none text-primary-foreground sm:text-[1.65rem]">
              S
            </span>
          </span>
        </span>
      </div>

      {/* Status line — keyed remount replays the fade-in without JS timers */}
      <p
        key={status}
        className="neural-core-status-fade px-6 text-center text-xs font-medium text-muted-foreground"
      >
        {status}
      </p>
    </div>
  )
}
