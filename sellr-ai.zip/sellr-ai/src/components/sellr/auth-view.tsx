'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowLeft, CheckCircle2, Loader2, Mail } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useSellr, SESSION_COOKIE_ERROR } from '@/store/sellr-store'
import { apiFetch } from '@/lib/client-api'
import type { AuthProvider, SessionUser } from '@/lib/types'
import { SellrLogo } from './shared'
import { MascotRow } from './mascots'
import { EASE_OUT, springSnappy } from './motion'

interface AuthViewProps {
  provider: AuthProvider
}

type AuthScreen = 'auth' | 'forgot' | 'reset' | 'verify'

const SCREEN_KEYS: AuthScreen[] = ['auth', 'forgot', 'reset', 'verify']

export function AuthView({ provider }: AuthViewProps) {
  const {
    authMode,
    setAuthMode,
    setUser,
    setView,
    view,
    bootstrap,
    pendingVerificationEmail,
    resetToken,
    requestPasswordReset,
    completePasswordReset,
    resendVerification,
    authNotice,
    setAuthNotice,
  } = useSellr()

  // `view` decides which screen renders: auth | forgot | reset | verify
  const screen: AuthScreen = SCREEN_KEYS.includes(view as AuthScreen) ? (view as AuthScreen) : 'auth'

  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [info, setInfo] = useState<string | null>(null)
  const [resetLink, setResetLink] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const isRegister = authMode === 'register'

  function headline() {
    switch (screen) {
      case 'forgot':
        return (
          <>
            Reset your <span className="text-primary">password</span>
          </>
        )
      case 'reset':
        return (
          <>
            Set a <span className="text-primary">new password</span>
          </>
        )
      case 'verify':
        return (
          <>
            Check your <span className="text-primary">inbox</span>
          </>
        )
      default:
        return (
          <>
            Meet your <span className="text-primary">AI business team</span>
          </>
        )
  }
  }

  function subline() {
    switch (screen) {
      case 'forgot':
        return 'Enter your account email and we will send a reset link.'
      case 'reset':
        return 'Choose a strong password — at least 8 characters.'
      case 'verify':
        return `We sent a verification link to ${pendingVerificationEmail ?? email}. Confirm your email to activate your team.`
      default:
        return isRegister
          ? 'Set up your team in under a minute — free to start.'
          : 'Welcome back. Your team kept everything on record.'
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setInfo(null)
    setLoading(true)
    try {
      // ---------- Forgot password ----------
      if (screen === 'forgot') {
        const result = await requestPasswordReset(email)
        if (result.resetUrl) {
          // Local provider without a mail service: the API returns the reset
          // link so the flow is completable in this environment.
          setResetLink(result.resetUrl)
          setInfo('No mail service is configured here, so use your reset link directly:')
        } else {
          setInfo(
            provider === 'supabase'
              ? 'Reset link sent. Check your inbox — the link opens a page to set a new password.'
              : 'If an account exists for that email, a reset link has been generated.'
          )
        }
        return
      }

      // ---------- Reset password ----------
      if (screen === 'reset') {
        if (password !== confirmPassword) {
          setError('Passwords do not match.')
          return
        }
        await completePasswordReset(password)
        setResetTokenCleanup()
        setInfo('Password updated. You can now sign in with your new password.')
        setEmail('')
        setPassword('')
        setConfirmPassword('')
        return
      }

      // ---------- Verify (resend) ----------
      if (screen === 'verify') {
        await resendVerification()
        setInfo('Verification email sent again. Check your inbox.')
        return
      }

      // ---------- Sign in / Register ----------
      if (isRegister) {
        const data = await apiFetch<{ user?: SessionUser; requiresVerification?: boolean }>(
          '/api/auth/register',
          {
            method: 'POST',
            body: JSON.stringify({ fullName, email, password }),
          }
        )
        if (data.requiresVerification) {
          // Supabase email confirmation is enabled — real email sent.
          setView('verify')
          setAuthMode('login')
          useSellr.setState({ pendingVerificationEmail: email })
          return
        }
        if (!data.user) {
          throw new Error(
            'Registration succeeded but the account could not be loaded. Please try again.'
          )
        }
        setUser(data.user)
      } else {
        const data = await apiFetch<{ user: SessionUser }>('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password }),
        })
        if (!data.user) {
          throw new Error(
            'Signed in but the account could not be loaded. Please try again.'
          )
        }
        setUser(data.user)
      }
      // Verify the session cookie actually persisted. If /api/auth/me comes
      // back empty, surface a visible error and STAY on the auth screen —
      // never silently fall back to the landing page.
      useSellr.setState({ sessionError: null })
      await bootstrap({ afterAuth: true })
      const { user: sessionUser, sessionError } = useSellr.getState()
      if (!sessionUser) {
        setError(sessionError ?? SESSION_COOKIE_ERROR)
        if (useSellr.getState().view !== 'auth') setView('auth')
        return
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  function setResetTokenCleanup() {
    // Token consumed — clear it from the store.
    useSellr.setState({ resetToken: null })
  }

  function goBackToAuth() {
    setError(null)
    setInfo(null)
    setResetLink(null)
    setAuthNotice(null)
    // Users coming from forgot/reset flows expect the sign-in tab.
    if (screen === 'reset' || screen === 'forgot') {
      setAuthMode('login')
    }
    setView('auth')
  }

  const textKey = `${screen}-${screen === 'auth' ? authMode : ''}`

  return (
    <div className="flex min-h-screen flex-col bg-[#FF4E00] p-2.5 sm:p-5 md:p-8 lg:p-10">
      {/* Dark app window — mirrors Whop's framed onboarding screen */}
      <motion.div
        className="relative flex min-h-[calc(100vh-1.25rem)] flex-1 flex-col overflow-hidden rounded-2xl bg-background shadow-[0_24px_80px_rgba(0,0,0,0.45)] sm:min-h-[calc(100vh-2.5rem)] sm:rounded-3xl md:min-h-[calc(100vh-4rem)] lg:min-h-[calc(100vh-5rem)]"
        initial={{ opacity: 0, y: 30, scale: 0.985, filter: 'blur(8px)' }}
        animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
        transition={{ duration: 0.6, ease: EASE_OUT }}
      >
        {/* Window chrome */}
        <div
          className="absolute left-5 top-4 hidden items-center gap-1.5 sm:flex"
          aria-hidden
        >
          <span className="h-3 w-3 rounded-full bg-[#FF5F57]" />
          <span className="h-3 w-3 rounded-full bg-[#FEBC2E]" />
          <span className="h-3 w-3 rounded-full bg-[#28C840]" />
        </div>

        {/* Header inside the window (dots live above the logo on sm+) */}
        <header className="flex items-center justify-between px-5 py-4 sm:px-7 sm:pt-11">
          <SellrLogo />
          <Button
            variant="ghost"
            size="sm"
            className="-mr-2 h-8 rounded-full text-muted-foreground hover:text-foreground"
            onClick={() => (screen === 'auth' ? setView('landing') : goBackToAuth())}
          >
            <ArrowLeft className="h-4 w-4" aria-hidden />
            {screen === 'auth' ? 'Back' : 'Back to sign in'}
          </Button>
        </header>

        {/* Content */}
        <main className="flex flex-1 items-center justify-center px-5 pb-10 pt-2 sm:px-7">
          <div className="w-full max-w-sm">
            {/* Headline crossfades between screens */}
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={textKey}
                className="mb-7 text-center"
                initial={{ opacity: 0, y: 10, filter: 'blur(4px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -8, filter: 'blur(4px)' }}
                transition={{ duration: 0.22, ease: EASE_OUT }}
              >
                <h1 className="text-balance text-3xl font-bold leading-tight tracking-tight md:text-4xl">
                  {headline()}
                </h1>
                <p className="mt-2.5 text-sm text-muted-foreground">{subline()}</p>
                {screen === 'auth' ? (
                  <MascotRow className="mt-5" size="h-9 w-9 md:h-11 md:w-11" gap="gap-3 md:gap-4" />
                ) : null}
              </motion.div>
            </AnimatePresence>

            <div className="rounded-2xl border border-border bg-card p-5 shadow-lg shadow-black/30 sm:p-6">
              {/* Auth notice from /auth/callback (email action errors) */}
              <AnimatePresence initial={false}>
                {authNotice ? (
                  <motion.p
                    key="auth-notice"
                    role="alert"
                    className="mb-4 overflow-hidden rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.25, ease: EASE_OUT }}
                  >
                    {authNotice.message}
                  </motion.p>
                ) : null}
              </AnimatePresence>

              {screen === 'auth' ? (
                <div
                  className="mb-5 grid grid-cols-2 gap-1 rounded-full bg-secondary p-1"
                  role="tablist"
                  aria-label="Authentication mode"
                >
                  {/* Sliding pill indicator — shared-layout transition */}
                  {(['register', 'login'] as const).map((mode) => {
                    const active = authMode === mode
                    return (
                      <button
                        key={mode}
                        type="button"
                        role="tab"
                        aria-selected={active}
                        onClick={() => {
                          setError(null)
                          setInfo(null)
                          setResetLink(null)
                          setAuthMode(mode)
                        }}
                        className="relative h-9 rounded-full text-sm font-semibold transition-colors"
                      >
                        {active ? (
                          <motion.span
                            layoutId="auth-tab-pill"
                            className="absolute inset-0 rounded-full bg-primary shadow-[0_2px_14px_rgba(255,78,0,0.4)]"
                            transition={springSnappy}
                          />
                        ) : null}
                        <span
                          className={`relative z-10 transition-colors ${
                            active ? 'text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          {mode === 'register' ? 'Create account' : 'Sign in'}
                        </span>
                      </button>
                    )
                  })}
                </div>
              ) : null}

              {/* Screen transitions: auth ↔ forgot ↔ reset ↔ verify */}
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={textKey}
                  initial={{ opacity: 0, x: 20, filter: 'blur(4px)' }}
                  animate={{ opacity: 1, x: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, x: -16, filter: 'blur(4px)' }}
                  transition={{ duration: 0.24, ease: EASE_OUT }}
                >
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {screen === 'auth' && isRegister ? (
                      <div className="space-y-1.5">
                        <Label htmlFor="fullName">Full name</Label>
                        <Input
                          id="fullName"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="Alex Rivera"
                          autoComplete="name"
                          required
                          minLength={2}
                          className="h-11 rounded-xl"
                        />
                      </div>
                    ) : null}

                    {screen === 'auth' || screen === 'forgot' ? (
                      <div className="space-y-1.5">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="you@business.com"
                          autoComplete="email"
                          required
                          className="h-11 rounded-xl"
                        />
                      </div>
                    ) : null}

                    {screen === 'auth' ? (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="password">Password</Label>
                          {!isRegister ? (
                            <button
                              type="button"
                              onClick={() => {
                                setError(null)
                                setView('forgot')
                              }}
                              className="text-xs font-medium text-primary hover:underline"
                            >
                              Forgot password?
                            </button>
                          ) : null}
                        </div>
                        <Input
                          id="password"
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder={isRegister ? 'At least 8 characters' : 'Your password'}
                          autoComplete={isRegister ? 'new-password' : 'current-password'}
                          required
                          minLength={isRegister ? 8 : 1}
                          className="h-11 rounded-xl"
                        />
                      </div>
                    ) : null}

                    {screen === 'reset' ? (
                      <>
                        <div className="space-y-1.5">
                          <Label htmlFor="newPassword">New password</Label>
                          <Input
                            id="newPassword"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="At least 8 characters"
                            autoComplete="new-password"
                            required
                            minLength={8}
                            className="h-11 rounded-xl"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="confirmPassword">Confirm password</Label>
                          <Input
                            id="confirmPassword"
                            type="password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            placeholder="Repeat your new password"
                            autoComplete="new-password"
                            required
                            minLength={8}
                            className="h-11 rounded-xl"
                          />
                        </div>
                      </>
                    ) : null}

                    {screen === 'verify' ? (
                      <div className="flex items-center gap-3 rounded-xl border border-border bg-secondary/60 px-3.5 py-3">
                        <Mail className="h-4 w-4 shrink-0 text-primary" aria-hidden />
                        <p className="text-xs leading-relaxed text-muted-foreground">
                          Didn&apos;t get the email? Check spam, or resend it below.
                        </p>
                      </div>
                    ) : null}

                    {/* Animated alerts */}
                    <AnimatePresence initial={false}>
                      {error ? (
                        <motion.p
                          key="auth-error"
                          role="alert"
                          className="overflow-hidden rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive"
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.25, ease: EASE_OUT }}
                        >
                          {error}
                        </motion.p>
                      ) : null}
                    </AnimatePresence>

                    <AnimatePresence initial={false}>
                      {info ? (
                        <motion.div
                          key="auth-info"
                          role="status"
                          className="overflow-hidden rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs leading-relaxed text-emerald-400"
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.25, ease: EASE_OUT }}
                        >
                          <span className="flex items-start gap-2">
                            <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                            <span className="flex-1">{info}</span>
                          </span>
                          {resetLink ? (
                            <a
                              href={resetLink}
                              className="mt-2 block break-all font-medium text-emerald-300 underline underline-offset-2"
                            >
                              {resetLink}
                            </a>
                          ) : null}
                        </motion.div>
                      ) : null}
                    </AnimatePresence>

                    <motion.div
                      className="w-full"
                      whileTap={loading ? undefined : { scale: 0.97 }}
                    >
                      <Button
                        type="submit"
                        className="h-11 w-full rounded-full text-sm font-semibold shadow-[0_4px_24px_rgba(255,78,0,0.4)] hover:shadow-[0_4px_32px_rgba(255,78,0,0.55)]"
                        disabled={loading}
                      >
                        {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
                        {screen === 'auth'
                          ? isRegister
                            ? 'Build my AI team'
                            : 'Sign in'
                          : screen === 'forgot'
                            ? 'Send reset link'
                            : screen === 'reset'
                              ? 'Update password'
                              : 'Resend email'}
                      </Button>
                    </motion.div>
                  </form>
                </motion.div>
              </AnimatePresence>
            </div>

            <p className="mt-4 text-center text-xs leading-relaxed text-muted-foreground">
              {screen === 'auth' && isRegister
                ? 'By creating an account you agree that SELLR.AI provides business guidance, not financial guarantees.'
                : screen === 'auth'
                  ? 'Sessions persist across refreshes on this device.'
                  : null}
            </p>
          </div>
        </main>

        {/* Footer bar inside the window */}
        <footer className="mt-auto flex items-center justify-between border-t border-border/60 px-5 py-3.5 sm:px-7">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-foreground">SELLR</span> — Your Personal AI
            Business Team
          </p>
          <p className="hidden text-xs tracking-[0.14em] text-muted-foreground sm:block">
            SEE → DECIDE → EXECUTE → MEASURE
          </p>
        </footer>
      </motion.div>
    </div>
  )
}
