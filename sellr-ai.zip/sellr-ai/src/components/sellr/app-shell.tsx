'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart3,
  Building2,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Menu,
  MessagesSquare,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { useSellr, type View } from '@/store/sellr-store'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import { SellrLogo } from './shared'
import { PageTransition, springSnappy } from './motion'

const NAV_ITEMS: { view: View; label: string; icon: typeof LayoutDashboard }[] = [
  { view: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { view: 'team', label: 'AI Business Team', icon: MessagesSquare },
  { view: 'actions', label: 'Action Center', icon: ListChecks },
  { view: 'analytics', label: 'Analytics', icon: BarChart3 },
  { view: 'business', label: 'Business Profile', icon: Building2 },
]

function NavList({ onNavigate, pillId = 'sellr-nav-pill' }: { onNavigate?: () => void; pillId?: string }) {
  const { view, setView } = useSellr()
  return (
    <nav aria-label="Main navigation" className="flex flex-col gap-1">
      {NAV_ITEMS.map((item) => {
        const active = view === item.view
        return (
          <button
            key={item.view}
            type="button"
            onClick={() => {
              setView(item.view)
              onNavigate?.()
            }}
            aria-current={active ? 'page' : undefined}
            className={cn(
              'relative flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
              active ? 'text-primary' : 'text-muted-foreground hover:bg-accent hover:text-foreground'
            )}
          >
            {/* Shared-layout active pill glides between nav items.
                Namespaced per surface (sidebar vs. sheet) to avoid layoutId collisions. */}
            {active ? (
              <motion.span
                layoutId={pillId}
                className="absolute inset-0 rounded-lg border border-primary/25 bg-primary/10"
                transition={springSnappy}
              />
            ) : null}
            <item.icon className="relative z-10 h-4 w-4" aria-hidden />
            <span className="relative z-10">{item.label}</span>
          </button>
        )
      })}
    </nav>
  )
}

function UserBlock() {
  const { user, logout } = useSellr()
  const [loggingOut, setLoggingOut] = useState(false)

  async function handleLogout() {
    setLoggingOut(true)
    await logout()
    toast.success('Signed out. See you soon.')
  }

  const initials = (user?.fullName ?? '?')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  return (
    <div className="rounded-lg border border-border bg-card/60 p-3">
      <div className="flex items-center gap-2.5">
        {user?.avatarUrl ? (
          <img
            src={user.avatarUrl}
            alt={`${user.fullName} profile photo`}
            className="h-8 w-8 shrink-0 rounded-full border border-border object-cover"
          />
        ) : (
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-semibold text-primary">
            {initials}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-medium">{user?.fullName}</p>
          <p className="truncate text-[11px] text-muted-foreground" title={user?.email}>
            {user?.email}
          </p>
        </div>
      </div>
      <Button
        variant="ghost"
        size="sm"
        className="mt-2 h-7 w-full justify-start px-2 text-xs text-muted-foreground"
        onClick={handleLogout}
        disabled={loggingOut}
      >
        <LogOut className="h-3.5 w-3.5" aria-hidden />
        Sign out
      </Button>
    </div>
  )
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const view = useSellr((s) => s.view)

  return (
    <div className="flex min-h-screen w-full">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-border bg-sidebar md:flex">
        <div className="flex h-14 items-center px-4">
          <SellrLogo />
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-2 scrollbar-slim">
          <NavList />
        </div>
        <div className="p-3">
          <UserBlock />
        </div>
      </aside>

      {/* Main column */}
      <div className="flex min-h-screen w-full flex-1 flex-col md:pl-60">
        {/* Mobile top bar */}
        <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-border bg-background/85 px-4 backdrop-blur md:hidden">
          <SellrLogo />
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open navigation menu">
                <Menu className="h-5 w-5" aria-hidden />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              aria-describedby={undefined}
              className="w-72 border-border bg-sidebar p-4"
            >
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <div className="mb-4">
                <SellrLogo />
              </div>
              <NavList onNavigate={() => setMobileOpen(false)} pillId="sellr-nav-pill-sheet" />
              <div className="absolute inset-x-4 bottom-4">
                <UserBlock />
              </div>
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1">
          {/* Content crossfades between sections; the shell itself never remounts */}
          <PageTransition
            pageKey={view}
            animateOnMount={false}
            className="mx-auto w-full max-w-6xl px-4 py-6 md:px-6 md:py-8"
          >
            {children}
          </PageTransition>
        </main>

        {/* Sticky footer: mt-auto keeps it at the bottom on short pages */}
        <footer className="mt-auto border-t border-border/60 bg-background">
          <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-1.5 px-4 py-3.5 text-xs text-muted-foreground sm:flex-row md:px-6">
            <p>© {new Date().getFullYear()} SELLR.AI — Your Personal AI Business Team</p>
            <p className="tracking-[0.14em]">SEE → DECIDE → EXECUTE → MEASURE</p>
          </div>
        </footer>
      </div>
    </div>
  )
}
