import { cookies, headers } from 'next/headers'
import { SignJWT, jwtVerify } from 'jose'
import bcrypt from 'bcryptjs'
import { randomBytes } from 'crypto'
import { readFileSync, writeFileSync } from 'fs'
import path from 'path'
import type { User } from '@supabase/supabase-js'
import { db } from '@/lib/db'
import { ApiError } from '@/lib/api-helpers'
import { isSupabaseConfigured, type AuthProvider } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'

const SESSION_COOKIE = 'sellr_session'
const SESSION_MAX_AGE = 60 * 60 * 24 * 30 // 30 days

/**
 * Resolve the session signing secret. Priority:
 *   1. SESSION_SECRET env var (min 32 chars)
 *   2. Persisted fallback file (db/.session-secret), generated once on boot.
 * The fallback guarantees auth never hard-fails in environments where the
 * env var is missing. The secret NEVER leaves the server.
 */
let cachedSecret: Uint8Array | null = null
function getSecretKey(): Uint8Array {
  if (cachedSecret) return cachedSecret

  const envSecret = process.env.SESSION_SECRET
  if (envSecret && envSecret.length >= 32) {
    cachedSecret = new TextEncoder().encode(envSecret)
    return cachedSecret
  }

  const secretFile = path.join(process.cwd(), 'db', '.session-secret')
  try {
    const persisted = readFileSync(secretFile, 'utf8').trim()
    if (persisted.length >= 32) {
      cachedSecret = new TextEncoder().encode(persisted)
      return cachedSecret
    }
  } catch {
    // First boot without env var — generate and persist below.
  }

  const generated = randomBytes(48).toString('base64url')
  try {
    writeFileSync(secretFile, generated, { mode: 0o600 })
    console.warn('[SELLR auth] SESSION_SECRET env missing — generated and persisted a fallback secret.')
  } catch (err) {
    // Read-only disk (sandboxed/ephemeral filesystems): never crash auth over
    // a secret we cannot persist — keep this process's secret in memory.
    console.error(
      '[SELLR auth] Could not persist the fallback session secret (read-only disk?). Using an in-memory secret for this process.',
      err
    )
  }
  cachedSecret = new TextEncoder().encode(generated)
  return cachedSecret
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

// ---------------------------------------------------------------------------
// Provider-aware identity resolution
// ---------------------------------------------------------------------------

export interface AuthIdentity {
  id: string
  email: string
  fullName: string
  avatarUrl: string | null
  emailVerified: boolean
  provider: AuthProvider
}

/**
 * Resolve the current user identity.
 *
 * Supabase (when configured): reads the session from cookies via the server
 * client. `getUser()` validates the JWT against Supabase's auth server —
 * a forged or stale cookie can never impersonate a user. The matching local
 * profile row is synced lazily so every business table can keep using
 * ownerId relations.
 *
 * Local (fallback): verifies the signed httpOnly session cookie.
 */
export async function getAuthUser(): Promise<AuthIdentity | null> {
  if (isSupabaseConfigured) {
    const supabaseUser = await getSupabaseUserOrNull()
    if (supabaseUser) {
      return ensureSupabaseProfile(supabaseUser)
    }
    // Fall through: a legacy local session may still be present.
  }
  return getLocalUserOrNull()
}

async function getSupabaseUserOrNull(): Promise<User | null> {
  try {
    const supabase = await createSupabaseServerClient()
    const { data, error } = await supabase.auth.getUser()
    if (error || !data.user) return null
    return data.user
  } catch {
    // Supabase unreachable or not configured — treat as no session.
    return null
  }
}

/**
 * Create/update the local profile row for a Supabase identity, and migrate
 * any legacy local-provider account with the same email so the user keeps
 * their business data when switching providers.
 */
export async function ensureSupabaseProfile(user: User): Promise<AuthIdentity> {
  const meta = (user.user_metadata ?? {}) as Record<string, unknown>
  const email = user.email ?? `${user.id}@unknown.invalid`
  const fullName =
    (typeof meta.full_name === 'string' && meta.full_name.trim()) ||
    (typeof meta.name === 'string' && meta.name.trim()) ||
    email.split('@')[0]
  const avatarUrl = typeof meta.avatar_url === 'string' && meta.avatar_url ? meta.avatar_url : null
  const emailVerified = Boolean(user.email_confirmed_at ?? user.confirmed_at)

  const profile = await db.$transaction(async (tx) => {
    const existing = await tx.user.findUnique({ where: { id: user.id } })
    if (existing) {
      return tx.user.update({
        where: { id: user.id },
        data: {
          email,
          fullName,
          avatarUrl,
          emailVerifiedAt: emailVerified ? new Date() : null,
        },
        select: PROFILE_SELECT,
      })
    }

    // Legacy local account with the same email? Re-assign its data to the
    // Supabase identity so nothing is lost, then remove the old row.
    const legacy = await tx.user.findUnique({ where: { email } })
    if (legacy) {
      await tx.user.update({
        where: { id: legacy.id },
        data: { email: `${legacy.id}@migrating.invalid` },
      })
      await tx.business.updateMany({ where: { ownerId: legacy.id }, data: { ownerId: user.id } })
      await tx.conversation.updateMany({ where: { userId: legacy.id }, data: { userId: user.id } })
      await tx.user.delete({ where: { id: legacy.id } })
    }

    return tx.user.create({
      data: {
        id: user.id,
        email,
        fullName,
        avatarUrl,
        emailVerifiedAt: emailVerified ? new Date() : null,
      },
      select: PROFILE_SELECT,
    })
  })

  return {
    id: profile.id,
    email: profile.email,
    fullName: profile.fullName,
    avatarUrl: profile.avatarUrl,
    emailVerified,
    provider: 'supabase',
  }
}

const PROFILE_SELECT = {
  id: true,
  email: true,
  fullName: true,
  avatarUrl: true,
  emailVerifiedAt: true,
} as const

async function getLocalUserOrNull(): Promise<AuthIdentity | null> {
  const userId = await getSessionUserId()
  if (!userId) return null
  const user = await db.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, fullName: true, avatarUrl: true, emailVerifiedAt: true },
  })
  if (!user) return null
  return {
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    avatarUrl: user.avatarUrl,
    emailVerified: Boolean(user.emailVerifiedAt),
    provider: 'local',
  }
}

const LOCAL_HOST_RE = /^(localhost|127\.\d+\.\d+\.\d+|::1|\[::1\]|\[::\]|0\.0\.0\.0|\*.local)(:\d+)?$/i

/**
 * Detect whether the BROWSER actually talks https to this app — directly or
 * through a TLS-terminating edge — so the session cookie carries the right
 * attributes. Never NODE_ENV.
 *
 * Why this is not just `x-forwarded-proto === 'https'`: gateway chains may
 * rewrite that header at the last hop. In this sandbox the preview edge
 * terminates TLS, then forwards over plain HTTP to a local Caddy listener,
 * which stamps X-Forwarded-Proto: http — while the browser is genuinely on
 * https (and inside an iframe, where only SameSite=None; Secure; Partitioned
 * cookies survive). So when forwarded headers are present AND the host is
 * public (non-local), the request necessarily arrived over a TLS edge.
 */
async function isBrowserOverHttps(): Promise<boolean> {
  try {
    const h = await headers()

    // Explicit TLS signal from a well-behaved proxy chain.
    const proto = h.get('x-forwarded-proto')?.split(',')[0]?.trim().toLowerCase()
    if (proto === 'https') return true

    // TLS terminated upstream, proto rewritten at the last hop: forwarded
    // headers + a public Host is the reliable https signal in that setup.
    const forwarded = h.get('x-forwarded-for') || h.get('x-forwarded-host')
    const host =
      (h.get('x-forwarded-host') ?? h.get('host'))?.split(',')[0]?.trim().toLowerCase() ?? ''
    if (forwarded && host && !LOCAL_HOST_RE.test(host)) return true

    return false
  } catch {
    return false
  }
}

/**
 * Session cookie attributes:
 *  - http local dev (no gateway): SameSite=Lax, not Secure — standard usage.
 *  - https browser (embedded preview / production): SameSite=None + Secure,
 *    and Partitioned (CHIPS) so the cookie survives inside cross-site iframe
 *    previews instead of being silently dropped by the browser.
 *    Browsers without CHIPS support ignore the Partitioned attribute.
 */
function sessionCookieAttributes(secure: boolean, maxAge: number) {
  if (secure) {
    return {
      httpOnly: true,
      sameSite: 'none',
      secure: true,
      partitioned: true,
      path: '/',
      maxAge,
    } as const
  }
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    path: '/',
    maxAge,
  } as const
}

/** Create a signed, httpOnly session cookie (never accessible from client JS). */
export async function createSession(userId: string): Promise<void> {
  const token = await new SignJWT({})
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(userId)
    .setIssuedAt()
    .setExpirationTime('30d')
    .sign(getSecretKey())

  const store = await cookies()
  store.set(
    SESSION_COOKIE,
    token,
    sessionCookieAttributes(await isBrowserOverHttps(), SESSION_MAX_AGE)
  )
}

export async function destroySession(): Promise<void> {
  const store = await cookies()
  store.set(SESSION_COOKIE, '', sessionCookieAttributes(await isBrowserOverHttps(), 0))
}

export async function getSessionUserId(): Promise<string | null> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (!token) return null
  try {
    const { payload } = await jwtVerify(token, getSecretKey())
    return typeof payload.sub === 'string' ? payload.sub : null
  } catch {
    return null
  }
}

export async function getCurrentUser(): Promise<AuthIdentity | null> {
  return getAuthUser()
}

/**
 * Server-side authorization gate. The user id ALWAYS comes from a verified
 * session (Supabase JWT validated server-side, or the signed local cookie) —
 * never from the request body (SELLR.md §13). This is the real route
 * protection: the SPA is convenience, this is the law.
 */
export async function requireUser(): Promise<AuthIdentity> {
  const user = await getCurrentUser()
  if (!user) throw new ApiError(401, 'You must be signed in to do that.')
  return user
}

/** Every business-scoped query resolves ownership from the session user. */
export async function requireBusiness(userId: string) {
  const business = await db.business.findFirst({ where: { ownerId: userId } })
  if (!business) throw new ApiError(404, 'No business found. Complete onboarding first.')
  return business
}

/**
 * Fetch an owned record through its business relation and verify ownership.
 * Returns null instead of leaking existence for foreign records.
 */
export async function findOwned<T extends { businessId: string }>(
  userId: string,
  model: { findUnique: (args: { where: { id: string } }) => Promise<T | null> },
  id: string
): Promise<T | null> {
  const record = await model.findUnique({ where: { id } })
  if (!record) return null
  const business = await db.business.findUnique({ where: { id: record.businessId } })
  if (!business || business.ownerId !== userId) return null
  return record
}
