// Shared, client-safe types (mirrors Prisma JSON serialization; dates as ISO strings)

export type AgentType = 'CEO' | 'ANALYST' | 'GROWTH' | 'RETENTION' | 'OPERATIONS'
export type Priority = 'HIGH' | 'MEDIUM' | 'LOW'
export type RecommendationStatus = 'SUGGESTED' | 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
export type TaskStatus = 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
export type ExperimentStatus = 'PLANNED' | 'RUNNING' | 'COMPLETED' | 'CANCELLED'
export type MetricType = 'REVENUE' | 'SALES' | 'CUSTOMERS' | 'CONVERSION' | 'AOV' | 'CHURN'

export type AuthProvider = 'supabase' | 'local'

export interface SessionUser {
  id: string
  email: string
  fullName: string
  avatarUrl?: string | null
  emailVerified?: boolean
  provider?: AuthProvider
}

export interface Business {
  id: string
  name: string
  businessType: string
  platform: string | null
  website: string | null
  description: string | null
  products: string | null
  targetAudience: string | null
  currentMonthlyRevenue: number | null
  monthlyRevenueGoal: number | null
  mainChallenge: string | null
  onboarded: boolean
  createdAt: string
  updatedAt: string
}

export interface BusinessMetric {
  id: string
  metricType: MetricType
  metricValue: number
  period: string // YYYY-MM
  source: string // MANUAL (Whop = future integration, never simulated)
  recordedAt: string
}

export interface Conversation {
  id: string
  agentType: AgentType
  title: string
  createdAt: string
  updatedAt: string
}

export interface PipelineStep {
  agent: AgentType
  action: string
}

export interface MessageMeta {
  pipeline?: PipelineStep[]
  agentsInvolved?: AgentType[]
  confidence?: string
  delegatedTo?: AgentType | null
}

export interface ChatMessage {
  id: string
  conversationId: string
  role: 'user' | 'assistant'
  content: string
  agentType: AgentType | null
  /** JSON-encoded MessageMeta (server stores meta as a string). */
  meta: string | null
  createdAt: string
}

export interface Recommendation {
  id: string
  agentType: AgentType
  title: string
  description: string
  priority: Priority
  expectedImpact: string | null
  status: RecommendationStatus
  createdAt: string
  taskCount?: number
}

export interface Task {
  id: string
  recommendationId: string | null
  title: string
  description: string | null
  assignedAgent: AgentType
  priority: Priority
  status: TaskStatus
  dueDate: string | null
  completedAt: string | null
  createdAt: string
}

export interface Experiment {
  id: string
  title: string
  hypothesis: string | null
  metric: string | null
  baselineValue: number | null
  targetValue: number | null
  resultValue: number | null
  status: ExperimentStatus
  createdAt: string
  completedAt: string | null
}

export interface ActivityItem {
  id: string
  type: string
  description: string
  agentType: AgentType | null
  createdAt: string
}

export interface MetricPoint {
  period: string
  value: number
}

export interface MetricSeries {
  latest: MetricPoint | null
  previous: MetricPoint | null
  deltaPct: number | null
  series: MetricPoint[]
}

export interface AnalyticsSummary {
  hasData: boolean
  dataSource: 'MANUAL'
  revenue: MetricSeries
  sales: MetricSeries
  customers: MetricSeries
  conversion: MetricSeries
  churn: MetricSeries
  aov: { value: number | null; note: string }
  goal: {
    target: number | null
    current: number | null
    progressPct: number | null
  }
  healthScore: {
    score: number
    label: string
    factors: string[]
  } | null
  metricCount: number
}

// ---- Agent display metadata (client-safe; icons mapped in components) ----

export const AGENT_META: Record<
  AgentType,
  { name: string; role: string; blurb: string; color: string; bg: string; border: string }
> = {
  CEO: {
    name: 'SELLR CEO',
    role: 'Main Coordinator',
    blurb: 'Understands your business, delegates to specialists, and synthesizes plans.',
    color: 'text-[#FF5A1F]',
    bg: 'bg-[#FF5A1F]/10',
    border: 'border-[#FF5A1F]/30',
  },
  ANALYST: {
    name: 'Analyst',
    role: 'Business Intelligence',
    blurb: 'Analyzes revenue, sales and conversion. Finds leaks and opportunities.',
    color: 'text-[#34D399]',
    bg: 'bg-[#34D399]/10',
    border: 'border-[#34D399]/30',
  },
  GROWTH: {
    name: 'Growth',
    role: 'Revenue Growth',
    blurb: 'Acquisition strategies, campaigns, pricing and upselling experiments.',
    color: 'text-[#FBBF24]',
    bg: 'bg-[#FBBF24]/10',
    border: 'border-[#FBBF24]/30',
  },
  RETENTION: {
    name: 'Retention',
    role: 'Customer Retention',
    blurb: 'Churn risks, engagement strategies, renewals and win-back campaigns.',
    color: 'text-[#F472B6]',
    bg: 'bg-[#F472B6]/10',
    border: 'border-[#F472B6]/30',
  },
  OPERATIONS: {
    name: 'Operations',
    role: 'Business Operations',
    blurb: 'Turns recommendations into prioritized, trackable execution plans.',
    color: 'text-[#22D3EE]',
    bg: 'bg-[#22D3EE]/10',
    border: 'border-[#22D3EE]/30',
  },
}

export const PRIORITY_STYLES: Record<Priority, string> = {
  HIGH: 'bg-red-500/10 text-red-400 border-red-500/30',
  MEDIUM: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  LOW: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
}

export const REC_STATUS_LABELS: Record<RecommendationStatus, string> = {
  SUGGESTED: 'Suggested',
  PLANNED: 'Planned',
  IN_PROGRESS: 'In Progress',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled',
}

export const TASK_STATUS_LABELS: Record<TaskStatus, string> = {
  PLANNED: 'Planned',
  IN_PROGRESS: 'In Progress',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled',
}

// ---- Whop integration (client-safe status shapes — no secrets) ----

export type WhopConnectionStatus =
  | 'CONNECTED'
  | 'SYNCING'
  | 'SYNC_FAILED'
  | 'REAUTH_REQUIRED'
  | 'DISCONNECTED'

export interface WhopSyncSummary {
  synced: number
  skippedExisting: number
  paymentsConsidered: number
  membershipsConsidered: number
  currency: string | null
  warnings: string[]
  productCount?: number
}

export interface WhopConnectionPublic {
  status: WhopConnectionStatus
  environment: 'sandbox' | 'production'
  whopAccountId: string
  whopAccountName: string | null
  whopRoute: string | null
  /** Last 4 characters of the stored key — identification only. */
  keyHint: string | null
  webhookRegistered: boolean
  lastSyncAt: string | null
  lastSyncError: string | null
  lastVerifiedAt: string | null
  summary: WhopSyncSummary | null
  /** Number of BusinessMetric rows sourced from Whop. */
  metricCount: number
  connectedAt: string
}

export interface WhopIntegrationStatus {
  /** Server can store credentials (WHOP_ENCRYPTION_KEY present and valid). */
  configured: boolean
  /** Public app URL is known, so webhook registration is offered. */
  webhookConfigured: boolean
  connection: WhopConnectionPublic | null
}
