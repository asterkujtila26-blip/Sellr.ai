/**
 * Supabase environment configuration.
 *
 * These are the ONLY variables needed to activate Supabase as the auth
 * provider. Detection is runtime — the app falls back to the built-in local
 * provider (bcrypt + signed-cookie sessions) when they are absent, so the
 * product keeps working before a Supabase project is attached.
 */

export const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL
export const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

/** Service-role key — server-only. NEVER read this in client code. */
export const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY

/**
 * Absolute origin used for email action redirects (confirmation / recovery).
 * Falls back to the request origin when unset.
 */
export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL

export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY)

export type AuthProvider = 'supabase' | 'local'

/** The active provider, resolvable on both server and client. */
export function getAuthProvider(): AuthProvider {
  return isSupabaseConfigured ? 'supabase' : 'local'
}
