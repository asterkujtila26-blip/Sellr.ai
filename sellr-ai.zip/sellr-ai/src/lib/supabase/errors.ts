import { ApiError } from '@/lib/api-helpers'
import type { AuthError } from '@supabase/supabase-js'

/**
 * Translate Supabase auth errors into safe, human API errors.
 * Never leak internal details (e.g. whether an email exists beyond what
 * Supabase itself discloses through its standard error codes).
 */
export function mapSupabaseAuthError(error: AuthError | null | undefined): ApiError {
  if (!error) return new ApiError(500, 'Authentication failed. Please try again.')

  const status =
    typeof error.status === 'number' && error.status >= 400 && error.status < 600
      ? error.status
      : 400

  switch (error.code) {
    case 'invalid_credentials':
      return new ApiError(401, 'Invalid email or password.')
    case 'user_already_exists':
    case 'email_exists':
      return new ApiError(409, 'An account with this email already exists. Try signing in.')
    case 'email_not_confirmed':
      return new ApiError(403, 'Please verify your email before signing in. Check your inbox.')
    case 'weak_password':
      return new ApiError(400, 'Password is too weak. Use at least 8 characters.')
    case 'over_email_send_rate_limit':
    case 'over_request_rate_limit':
      return new ApiError(429, 'Too many emails sent. Please wait a minute and try again.')
    case 'user_banned':
      return new ApiError(403, 'This account has been disabled.')
    case 'same_password':
      return new ApiError(400, 'Choose a password different from your current one.')
    case 'validation_failed':
      return new ApiError(400, error.message || 'Please check your input and try again.')
    default:
      return new ApiError(status, error.message || 'Authentication failed. Please try again.')
  }
}
