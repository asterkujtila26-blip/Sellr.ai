import { createBrowserClient } from '@supabase/ssr'
import type { SupabaseClient } from '@supabase/supabase-js'
import { SUPABASE_ANON_KEY, SUPABASE_URL, isSupabaseConfigured } from './config'

let client: SupabaseClient | null = null

/**
 * Browser-side Supabase client.
 *
 * Safe for the browser: uses the PUBLIC anon key only (never service_role).
 * The @supabase/ssr browser client persists the session in cookies and
 * auto-refreshes access tokens, so a page refresh never logs the user out.
 */
export function createSupabaseBrowserClient(): SupabaseClient {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.')
  }
  if (!client) {
    client = createBrowserClient(SUPABASE_URL!, SUPABASE_ANON_KEY!)
  }
  return client
}
