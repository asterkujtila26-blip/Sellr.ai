# SELLR.AI

Ekipi AI i biznesit tënd — Next.js 16 · Prisma (PostgreSQL) · Tailwind · shadcn/ui.

## Publikimi: GitHub → Vercel

### 1. Baza e të dhënave (PostgreSQL, falas)
1. Krijo një projekt në [neon.tech](https://neon.tech) (ose Supabase).
2. Kopjo lidhjen **direkte** — Neon: fik "Connection pooling"; Supabase: "Session pooler" (porti 5432). Ky është `DATABASE_URL`.

### 2. GitHub
1. Krijo një repo të ri **bosh** në GitHub.
2. Ngarko përmbajtjen e kësaj dosjeje (jo vetë dosjen). Nga terminali:
   ```bash
   git init
   git add .
   git commit -m "SELLR.AI"
   git branch -M main
   git remote add origin https://github.com/EMRI-YT/EMRI-REPO.git
   git push -u origin main
   ```
   Nëse e ngarkon nga shfletuesi (Add file → Upload files), GitHub pranon deri 100 skedarë njëherësh — ngarko në 2 raunde.

### 3. Vercel
1. vercel.com → **Add New → Project** → zgjidh repo-n.
2. Framework: Next.js (zbulohet vetë). Te **Environment Variables** shto variablat e tabelës më poshtë.
3. **Deploy**. Tabelat e bazës krijohen vetë gjatë build-it (`prisma db push`).

## Variablat

| Emri | Detyrueshëm | Shënim |
|---|---|---|
| `DATABASE_URL` | Po | Lidhja PostgreSQL (direkte) |
| `SESSION_SECRET` | Po | 32+ karaktere të rastësishme: `openssl rand -base64 48` |
| `OPENAI_API_KEY` | Për AI | Pa të, agjentët AI nuk punojnë në Vercel |
| `OPENAI_MODEL` | Jo | Default: `gpt-5.4-mini` |
| `NEXT_PUBLIC_SITE_URL` | Rekomandohet | URL e faqes, p.sh. `https://emri.vercel.app` (pa `/` në fund). Shtoje pas deploy-it të parë dhe bëj Redeploy |
| `WHOP_ENCRYPTION_KEY` | Vetëm për Whop | 64 shkronja hex: `openssl rand -hex 32` |
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` | Jo | Nëse mungojnë, përdoret hyrja e brendshme (email + fjalëkalim) |

Supabase Auth: shto `https://DOMENI-JOT/auth/callback` te Authentication → URL Configuration.

## Lokalisht

```bash
npm install
cp .env.example .env     # plotëso DATABASE_URL dhe SESSION_SECRET
npm run db:push
npm run dev
```

## Ndryshime kundrejt versionit nga Z.ai
- SQLite → PostgreSQL (SQLite nuk punon në Vercel).
- Scripts të build-it të pastruara për Vercel; hequr `output: "standalone"`.
- AI: shtuar OpenAI (`OPENAI_API_KEY`); `z-ai-web-dev-sdk` mbetet fallback vetëm brenda Z.ai.
- `/api/agents/chat`: `maxDuration = 60`.
- Logjet e query-ve të Prisma aktive vetëm jashtë production.
- Hequr: `.env`, `db/` (baza lokale + session secret), historiku `.git` dhe skedarët e ambientit Z.ai.
