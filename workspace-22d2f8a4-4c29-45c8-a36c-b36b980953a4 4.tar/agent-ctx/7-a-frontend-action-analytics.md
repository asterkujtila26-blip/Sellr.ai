# Task 7-a — Frontend: Action Center + Analytics views

Agent: Z.ai Code (frontend agent, task ID 7-a)
Date: 2026-02-27
Status: ✅ Completed

## Files created (no other files touched)

1. `/home/z/my-project/src/components/sellr/action-center-view.tsx`
   - Named export: `ActionCenterView()` (client component, no props)
2. `/home/z/my-project/src/components/sellr/analytics-view.tsx`
   - Named export: `AnalyticsView()` (client component, no props)

## ActionCenterView — features

- Header "Action Center" + subtitle; shadcn Tabs: Recommendations / Tasks / Experiments.
- All three datasets loaded in parallel on mount (`Promise.all` of GET /api/recommendations, /api/tasks, /api/experiments); per-tab skeletons while loading; error banner with retry.
- **Recommendations tab**: responsive card grid (AgentChip, PriorityBadge, StatusPill, title, description, TrendingUp expectedImpact, "{n} linked task(s)" hint, timeAgo). Per-card status Select (5 statuses → PATCH). "Convert to task" button when `taskCount === 0`: POST /api/tasks (title, description, recommendationId, assignedAgent, priority) then PATCH recommendation → PLANNED; local lists updated; toast "Task created from recommendation". Delete via DropdownMenu → shared AlertDialog confirm. EmptyState (ListChecks).
- **Tasks tab**: status filter buttons (All/Planned/In Progress/Completed/Cancelled) + "New task" Dialog (title*, description, agent Select with AGENT_META names, priority Select, Input type="date") → POST, toast "Task created", prepend. Task rows: checkbox-style advance button cycling PLANNED→IN_PROGRESS→COMPLETED (CANCELLED→PLANNED), StatusPill, PriorityBadge, AgentChip, due date (red + "overdue" when past and not completed), DropdownMenu with explicit status actions incl. reopen + delete w/ confirm. Completing PATCHes 'COMPLETED' + toast "Task completed". Empty states for no tasks and no match for filter.
- **Experiments tab**: "New experiment" Dialog (title*, hypothesis, metric, baseline, target) → POST, prepend, toast. Cards: title, hypothesis, metric (FlaskConical), "Baseline x → Target y", result value (emerald) when present, custom experiment status badge (PLANNED amber / RUNNING #22D3EE / COMPLETED emerald / CANCELLED zinc), status Select. Selecting COMPLETED with `resultValue == null` shows inline result input; Save PATCHes `{ status: 'COMPLETED', resultValue }` in a single request; toast "Experiment completed". Delete via DropdownMenu → confirm.
- Shared root AlertDialog for all deletions (recommendation/task/experiment), sonner toasts for success/error, per-item busy states.

## AnalyticsView — features

- Header "Analytics" + subtitle "Real numbers in, honest analysis out."
- Loads GET /api/analytics/summary + GET /api/metrics in parallel; full-page skeleton; error banner with retry.
- **Empty state** (`metricCount === 0`): EmptyState (BarChart3, "No metrics yet") above the metric entry form; KPIs/charts/table hidden.
- **KPI cards** (grid-cols-2 lg:grid-cols-4): Monthly Revenue, Sales, Active Customers, Conversion — value via `formatMetricValue`, period label (e.g. "Jan 2025"), MoM delta chip (▲ emerald / ▼ red, `deltaPct`), honest "No data" + hint per metric.
- **Revenue goal card**: current/target + shadcn Progress (clamped 0–100) + "% of target achieved"; dashed hint "Set a revenue objective in Business Profile" when `goal.target == null`.
- **Business health card**: score (text-3xl, emerald/amber/red by band), label chip, factor list, microcopy "Heuristic estimate based on your recorded data."; "Add metrics to compute business health." when null.
- **Charts** (grid lg:grid-cols-2, ResponsiveContainer height 260, CartesianGrid #292D35 dashed, dark Tooltip contentStyle #111318/#292D35, ticks #9297A2/11px): Revenue trend AreaChart (stroke #8B7CFF, fill rgba(139,124,255,0.12), compact-money Y ticks, exact-money tooltip) and Sales & customers LineChart (sales #FBBF24, customers #22D3EE, merged by period, compact ticks, custom color-dot legend). "No data" fallback text per chart.
- **Metric entry form card**: type Select (6 friendly labels), value Input (inputMode decimal), period Input type="month" (client-validated `^\d{4}-(0[1-9]|1[0-2])$`), inline validation errors, Plus "Add metric" submit → POST /api/metrics → toast "Metric saved" → silent refresh of summary + metrics. Data-source notice box: "Data source: Manual entry. Direct platform integrations (e.g. Whop) are on the roadmap — SELLR never fabricates business metrics."
- **Recorded metrics table** (lg:col-span-2, `max-h-[420px] overflow-y-auto scrollbar-slim`, sticky header): Metric label, Value (`formatMetricValue` non-compact), Period, Source Badge (MANUAL), timeAgo(recordedAt), Trash2 delete with AlertDialog confirm → DELETE /api/metrics/:id → toast + silent refresh. Sorted newest period first, latest 20 rows.
- Layout: bottom section `grid lg:grid-cols-3` — form card (1 col) beside table (2 cols).

## Verification

- `bun run lint` → clean (no output, no errors/warnings project-wide; my two files included).
- `bunx tsc --noEmit` → zero errors in action-center-view.tsx / analytics-view.tsx (remaining tsc errors are in files owned by other agents: sellr-app.tsx missing sibling views, api/agents/chat/route.ts, examples/, skills/ — not touched per instructions).
- dev.log shows module-not-found only for `./dashboard-view`, `./team-view`, `./business-view` (other agents' concurrent work). My two files resolve and compile.

## API/type notes observed (reported, not fixed)

1. `GET /api/recommendations` items include computed `taskCount?`, but `PATCH /api/recommendations/:id → { recommendation }` may not include it — I merge the PATCH result while preserving the local `taskCount`.
2. `POST /api/tasks` body contract says `assignedAgent?: AgentType (default 'OPERATIONS')` and optional fields; I send `description`/`dueDate` as `undefined` (omitted via JSON.stringify) when empty — server must treat missing as null. `dueDate` is sent as a full ISO string (converted from the date input) matching `Task.dueDate: string | null`.
3. Analytics summary response also returns `business: Business` (typed, unused by the UI — goal info comes from `summary.goal`).
4. `summary.hasData` vs `summary.metricCount` — I show the full dashboard when either indicates data, and the empty state when `metricCount === 0`; per-metric cards handle "No data" honestly, so partial data never fabricates numbers.
5. `POST /api/metrics` is an upsert per (type, period) — after save/delete I re-fetch summary + metrics rather than patching local state, since the server recomputes series/health.
